Place the pretrained **HiFi-GAN universal** generator here as `generator_universal.pth.tar`.
It is the vocoder shipped with https://github.com/ming024/FastSpeech2 (see "Pre-trained vocoder" in its README;
the file is distributed as `generator_universal.pth.tar.zip` -- unzip it).
Both languages use this same vocoder (it is trained on many speakers, so it also works for Telugu mel-spectrograms
with the same 22.05 kHz / 80-mel / hop-256 settings).  Vocoder weights are not committed to git.
