"""Mel-spectrogram / energy extraction (HiFi-GAN-compatible: natural-log mel, centre=False)."""
import librosa
import torch
import torch.nn.functional as F


class MelExtractor:
    def __init__(self, sr=22050, n_fft=1024, hop=256, win=1024, n_mels=80, fmin=0, fmax=8000):
        self.n_fft, self.hop, self.win = n_fft, hop, win
        self.basis = torch.from_numpy(librosa.filters.mel(sr=sr, n_fft=n_fft, n_mels=n_mels, fmin=fmin, fmax=fmax)).float()
        self.window = torch.hann_window(win)

    def __call__(self, wav):
        """wav: 1-D float tensor in [-1, 1] -> (mel [T, n_mels], energy [T])"""
        pad = (self.n_fft - self.hop) // 2
        y = F.pad(wav[None, None], (pad, pad), mode="reflect").squeeze(1)
        spec = torch.stft(y, self.n_fft, self.hop, self.win, self.window, center=False, return_complex=True)
        mag = torch.sqrt(spec.real ** 2 + spec.imag ** 2 + 1e-9)          # [1, F, T]
        mel = torch.log(torch.clamp(self.basis @ mag, min=1e-5))           # [1, n_mels, T]
        energy = torch.norm(mag, dim=1)                                    # [1, T]  (L2 norm of STFT frame)
        return mel[0].T.numpy(), energy[0].numpy()
