"""HiFi-GAN V1 generator (same layer names as the official / ming024 checkpoints, so the pretrained
`generator_universal.pth.tar` loads directly)."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import remove_weight_norm, weight_norm


def _pad(k, d=1):
    return (k * d - d) // 2


class ResBlock1(nn.Module):
    def __init__(self, ch, ks=3, dilation=(1, 3, 5)):
        super().__init__()
        self.convs1 = nn.ModuleList(weight_norm(nn.Conv1d(ch, ch, ks, 1, dilation=d, padding=_pad(ks, d))) for d in dilation)
        self.convs2 = nn.ModuleList(weight_norm(nn.Conv1d(ch, ch, ks, 1, dilation=1, padding=_pad(ks, 1))) for _ in dilation)

    def forward(self, x):
        for c1, c2 in zip(self.convs1, self.convs2):
            x = c2(F.leaky_relu(c1(F.leaky_relu(x, 0.1)), 0.1)) + x
        return x

    def remove_weight_norm(self):
        for l in list(self.convs1) + list(self.convs2):
            remove_weight_norm(l)


class Generator(nn.Module):
    def __init__(self, init_ch=512, up_rates=(8, 8, 2, 2), up_ks=(16, 16, 4, 4),
                 rb_ks=(3, 7, 11), rb_dil=((1, 3, 5),) * 3, n_mels=80):
        super().__init__()
        self.nk = len(rb_ks)
        self.conv_pre = weight_norm(nn.Conv1d(n_mels, init_ch, 7, 1, padding=3))
        self.ups = nn.ModuleList(
            weight_norm(nn.ConvTranspose1d(init_ch // 2 ** i, init_ch // 2 ** (i + 1), k, u, padding=(k - u) // 2))
            for i, (u, k) in enumerate(zip(up_rates, up_ks)))
        self.resblocks = nn.ModuleList()
        for i in range(len(self.ups)):
            ch = init_ch // 2 ** (i + 1)
            for k, d in zip(rb_ks, rb_dil):
                self.resblocks.append(ResBlock1(ch, k, d))
        self.conv_post = weight_norm(nn.Conv1d(ch, 1, 7, 1, padding=3))

    def forward(self, x):
        x = self.conv_pre(x)
        for i, up in enumerate(self.ups):
            x = up(F.leaky_relu(x, 0.1))
            xs = sum(self.resblocks[i * self.nk + j](x) for j in range(self.nk))
            x = xs / self.nk
        return torch.tanh(self.conv_post(F.leaky_relu(x)))

    def remove_weight_norm(self):
        for l in self.ups:
            remove_weight_norm(l)
        for l in self.resblocks:
            l.remove_weight_norm()
        remove_weight_norm(self.conv_pre)
        remove_weight_norm(self.conv_post)


def load_vocoder(ckpt_path, device):
    g = Generator()
    g.load_state_dict(torch.load(ckpt_path, map_location=device)["generator"])
    g.eval()
    g.remove_weight_norm()
    return g.to(device)
