"""Stage 3 of preprocessing: MFA TextGrids + wavs -> phoneme durations, mel, phoneme-level pitch/energy."""
import json
import re
from pathlib import Path

import numpy as np
import pyworld as pw
import tgt
import torch
import librosa
from scipy.interpolate import interp1d
from tqdm import tqdm

from .audio import MelExtractor
from .utils import rel, write_json

SIL = {"sil", "sp", "spn", ""}


def get_alignment(tier, sr, hop, fix_phone):
    phones, durs, start, end, end_idx = [], [], None, None, 0
    for t in tier._objects:
        s, e, p = t.start_time, t.end_time, t.text
        n = int(round(e * sr / hop) - round(s * sr / hop))
        if p.lower() in SIL:
            if start is not None:                    # keep inner pauses, drop leading silence
                phones.append("sp"); durs.append(n)
        else:
            start = s if start is None else start
            end = e
            phones.append(fix_phone(p)); durs.append(n)
            end_idx = len(phones)                    # drop trailing silence
    return phones[:end_idx], durs[:end_idx], start, end


def _norm(v, mean, std):
    return (v - mean) / std


def run(cfg, fix_phone=lambda p: p):
    sr, hop = cfg["audio"]["sampling_rate"], cfg["stft"]["hop_length"]
    pp = rel(cfg, cfg["path"]["preprocessed_path"])
    raw, tg_dir = rel(cfg, cfg["path"]["raw_path"]), rel(cfg, cfg["path"]["textgrid_path"])
    for k in ("mel", "pitch", "energy", "duration"):
        (pp / k).mkdir(parents=True, exist_ok=True)
    mel_fn = MelExtractor(sr, cfg["stft"]["filter_length"], hop, cfg["stft"]["win_length"],
                          cfg["mel"]["n_mel_channels"], cfg["mel"]["mel_fmin"], cfg["mel"]["mel_fmax"])
    manifest = json.load(open(pp / "split_manifest.json", encoding="utf-8"))
    rows, symbols, speakers, p_all, e_all = {"train": [], "val": []}, set(), {}, [], []
    kept = {"train": 0, "val": 0}

    for m in tqdm(manifest, desc="features"):
        spk, uid = m["speaker"], m["id"]
        tg_path = tg_dir / spk / f"{uid}.TextGrid"
        if not tg_path.exists():
            continue
        tier = tgt.io.read_textgrid(str(tg_path)).get_tier_by_name("phones")
        phones, durs, start, end = get_alignment(tier, sr, hop, fix_phone)
        if not phones or start is None or end <= start:
            continue
        wav, _ = librosa.load(raw / spk / f"{uid}.wav", sr=sr)
        wav = wav[int(sr * start): int(sr * end)].astype(np.float32)
        pitch, t = pw.dio(wav.astype(np.float64), sr, frame_period=hop / sr * 1000)
        pitch = pw.stonemask(wav.astype(np.float64), pitch, t, sr)
        mel, energy = mel_fn(torch.from_numpy(wav))
        n = min(len(mel), len(pitch), len(energy))
        diff = sum(durs) - n
        if diff > 0:                                  # alignment slightly longer than audio
            if diff > 2 or durs[-1] - diff < 0:
                continue
            durs[-1] -= diff
        elif diff < 0:
            n = sum(durs)
        mel, pitch, energy = mel[:n], pitch[:n], energy[:n]
        if np.count_nonzero(pitch) <= 1:
            continue
        nz = np.where(pitch != 0)[0]                  # linear interpolation over unvoiced frames
        pitch = interp1d(nz, pitch[nz], fill_value=(pitch[nz[0]], pitch[nz[-1]]), bounds_error=False)(np.arange(n))
        p_ph, e_ph, pos = [], [], 0
        for d in durs:                                # phoneme-level averaging
            p_ph.append(pitch[pos:pos + d].mean() if d > 0 else 0.0)
            e_ph.append(energy[pos:pos + d].mean() if d > 0 else 0.0)
            pos += d
        sp = f"{spk}"
        np.save(pp / "mel" / f"{sp}-mel-{uid}.npy", mel.astype(np.float32))
        np.save(pp / "pitch" / f"{sp}-pitch-{uid}.npy", np.array(p_ph, dtype=np.float32))
        np.save(pp / "energy" / f"{sp}-energy-{uid}.npy", np.array(e_ph, dtype=np.float32))
        np.save(pp / "duration" / f"{sp}-duration-{uid}.npy", np.array(durs, dtype=np.int64))
        rows[m["split"]].append(f"{uid}|{spk}|{{{' '.join(phones)}}}|{m['text']}")
        kept[m["split"]] += 1
        symbols.update(phones); speakers.setdefault(spk, len(speakers))
        if m["split"] == "train":
            p_all.extend(p for p in p_ph if p > 0); e_all.extend(e_ph)

    pm, ps, em, es = np.mean(p_all), np.std(p_all), np.mean(e_all), np.std(e_all)
    # normalise phoneme-level pitch/energy with global train statistics, then record min/max for binning
    pmin, pmax, emin, emax = 1e9, -1e9, 1e9, -1e9
    for split in rows:
        for line in rows[split]:
            uid, spk = line.split("|")[:2]
            for k, mean, std in (("pitch", pm, ps), ("energy", em, es)):
                f = pp / k / f"{spk}-{k}-{uid}.npy"
                v = _norm(np.load(f), mean, std).astype(np.float32)
                np.save(f, v)
                if split == "train":
                    if k == "pitch": pmin, pmax = min(pmin, v.min()), max(pmax, v.max())
                    else: emin, emax = min(emin, v.min()), max(emax, v.max())
    write_json({"pitch": [float(pmin), float(pmax), float(pm), float(ps)],
                "energy": [float(emin), float(emax), float(em), float(es)]}, pp / "stats.json")
    write_json(sorted(symbols), pp / "symbols.json")
    write_json(speakers, pp / "speakers.json")
    for split, lines in rows.items():
        (pp / f"{split}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("kept utterances:", kept, "| symbols:", len(symbols), "| speakers:", len(speakers))
