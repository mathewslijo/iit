import numpy as np
import torch
from torch.utils.data import Dataset

from .utils import read_json, rel


class TTSDataset(Dataset):
    def __init__(self, cfg, split):
        self.dir = rel(cfg, cfg["path"]["preprocessed_path"])
        self.s2i = {s: i + 1 for i, s in enumerate(read_json(self.dir / "symbols.json"))}  # 0 = pad
        self.spk = read_json(self.dir / "speakers.json")
        with open(self.dir / f"{split}.txt", encoding="utf-8") as f:
            self.items = [l.rstrip("\n").split("|") for l in f if l.strip()]

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        base, spk, phones, _raw = self.items[i]
        ld = lambda k: np.load(self.dir / k / f"{spk}-{k}-{base}.npy")
        ids = [self.s2i[p] for p in phones.strip("{}").split()]
        return dict(id=base, spk=self.spk[spk], text=np.array(ids), mel=ld("mel"),
                    pitch=ld("pitch"), energy=ld("energy"), duration=ld("duration"))


def collate(batch):
    pad = lambda arrs, dt: torch.nn.utils.rnn.pad_sequence([torch.as_tensor(a, dtype=dt) for a in arrs], batch_first=True)
    return dict(
        ids=[b["id"] for b in batch],
        speakers=torch.tensor([b["spk"] for b in batch]),
        texts=pad([b["text"] for b in batch], torch.long),
        src_lens=torch.tensor([len(b["text"]) for b in batch]),
        mels=pad([b["mel"] for b in batch], torch.float),
        mel_lens=torch.tensor([len(b["mel"]) for b in batch]),
        pitches=pad([b["pitch"] for b in batch], torch.float),
        energies=pad([b["energy"] for b in batch], torch.float),
        durations=pad([b["duration"] for b in batch], torch.long),
    )
