"""Training loop, validation, checkpointing, CSV loss logging and loss-curve plotting."""
import csv
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from .data import TTSDataset, collate
from .model import LOSS_NAMES, build_model, fs2_loss
from .utils import load_config, rel


class ScheduledOptim:
    """Noam-style warm-up + step annealing, as in the reference implementation."""

    def __init__(self, model, tcfg, hidden, step=0):
        self.opt = torch.optim.Adam(model.parameters(), betas=(0.9, 0.98), eps=1e-9)
        self.n, self.warm = step, tcfg["warm_up_step"]
        self.anneal_steps, self.rate, self.init = tcfg["anneal_steps"], tcfg["anneal_rate"], hidden ** -0.5

    def lr(self):
        lr = self.init * min(self.n ** -0.5, self.n * self.warm ** -1.5)
        return lr * self.rate ** sum(self.n > s for s in self.anneal_steps)

    def step(self):
        self.n += 1
        for g in self.opt.param_groups:
            g["lr"] = self.lr()
        self.opt.step()


def _to(batch, dev):
    return {k: (v.to(dev) if torch.is_tensor(v) else v) for k, v in batch.items()}


def _forward(model, b):
    o = model(b["speakers"], b["texts"], b["src_lens"], mel_lens=b["mel_lens"], pitches=b["pitches"],
              energies=b["energies"], durations=b["durations"])
    return fs2_loss(o, b["mels"], b["pitches"], b["energies"], b["durations"])


@torch.no_grad()
def evaluate(model, loader, dev):
    """Validation loss (teacher-forced: ground-truth duration/pitch/energy are fed to the decoder)."""
    model.eval()
    tot, n = torch.zeros(len(LOSS_NAMES)), 0
    for b in loader:
        b = _to(b, dev)
        tot += _forward(model, b).cpu() * len(b["ids"])
        n += len(b["ids"])
    model.train()
    return (tot / n).tolist()


def read_log(path):
    with open(path, newline="") as f:
        r = list(csv.DictReader(f))
    return np.array([[float(x[k]) for k in ["step"] + LOSS_NAMES] for x in r]) if r else np.zeros((0, 7))


def plot_losses(log_dir, out_dir, title):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    out_dir.mkdir(parents=True, exist_ok=True)
    for split, fname in (("train", "training_loss.png"), ("val", "validation_loss.png")):
        p = log_dir / f"{split}_loss.csv"
        if not p.exists():
            continue
        a = read_log(p)
        if not len(a):
            continue
        fig, ax = plt.subplots(1, 2, figsize=(12, 4))
        for j, name in enumerate(LOSS_NAMES):
            y = a[:, j + 1]
            if split == "train" and len(y) > 20:
                y = np.convolve(y, np.ones(10) / 10, mode="valid"); x = a[9:, 0]
            else:
                x = a[:, 0]
            ax[0 if name == "total" else 1].plot(x, y, label=name, lw=2 if name == "total" else 1.2)
        if split == "val":
            b = a[:, 1].argmin()
            ax[0].axvline(a[b, 0], ls="--", c="gray", label=f"best step {int(a[b, 0])}")
        ax[0].set_title(f"{title}: {split} total loss"); ax[1].set_title(f"{title}: {split} loss components")
        for x_ in ax:
            x_.set_xlabel("step"); x_.set_ylabel("loss"); x_.legend(); x_.grid(alpha=.3)
        fig.tight_layout(); fig.savefig(out_dir / fname, dpi=150); plt.close(fig)


def run(cfg_path, resume=None, plot_only=False):
    cfg = load_config(cfg_path)
    tc, paths = cfg["train"], cfg["path"]
    ckpt_dir, log_dir, res_dir = rel(cfg, paths["ckpt_path"]), rel(cfg, paths["log_path"]), rel(cfg, paths["results_path"])
    for d in (ckpt_dir, log_dir):
        d.mkdir(parents=True, exist_ok=True)
    title = cfg["language"].capitalize()
    if plot_only:
        plot_losses(log_dir, res_dir, title); return

    torch.manual_seed(tc["seed"]); np.random.seed(tc["seed"])
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_dl = DataLoader(TTSDataset(cfg, "train"), tc["batch_size"], shuffle=True, collate_fn=collate,
                          num_workers=tc["num_workers"], drop_last=True)
    val_dl = DataLoader(TTSDataset(cfg, "val"), tc["batch_size"], shuffle=False, collate_fn=collate,
                        num_workers=tc["num_workers"])
    model = build_model(cfg).to(dev)
    opt = ScheduledOptim(model, tc, cfg["model"]["hidden"])
    step, best = 0, float("inf")
    if resume:
        ck = torch.load(resume, map_location=dev)
        model.load_state_dict(ck["model"]); opt.opt.load_state_dict(ck["optimizer"])
        step, opt.n, best = ck["step"], ck["step"], ck.get("best", best)
    print(f"{title}: {sum(p.numel() for p in model.parameters()) / 1e6:.1f}M params | device {dev} | "
          f"{len(train_dl.dataset)} train / {len(val_dl.dataset)} val utts")

    fh = {}
    for split in ("train", "val"):
        new = not (log_dir / f"{split}_loss.csv").exists() or not resume
        fh[split] = open(log_dir / f"{split}_loss.csv", "w" if new else "a", newline="")
        if new:
            csv.writer(fh[split]).writerow(["step"] + LOSS_NAMES)
    acc, cnt, t0 = torch.zeros(len(LOSS_NAMES)), 0, time.time()
    model.train()
    while step < tc["total_step"]:
        for b in train_dl:
            b = _to(b, dev)
            losses = _forward(model, b)
            opt.opt.zero_grad(); losses[0].backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), tc["grad_clip"])
            opt.step(); step += 1
            acc += losses.detach().cpu(); cnt += 1
            if step % tc["log_step"] == 0:
                avg = (acc / cnt).tolist(); acc, cnt = torch.zeros(len(LOSS_NAMES)), 0
                csv.writer(fh["train"]).writerow([step] + [f"{v:.5f}" for v in avg]); fh["train"].flush()
                print(f"step {step}/{tc['total_step']} | " + " ".join(f"{n} {v:.4f}" for n, v in zip(LOSS_NAMES, avg))
                      + f" | lr {opt.lr():.2e} | {time.time() - t0:.0f}s")
            if step % tc["val_step"] == 0:
                v = evaluate(model, val_dl, dev)
                csv.writer(fh["val"]).writerow([step] + [f"{x:.5f}" for x in v]); fh["val"].flush()
                print(f"  [val] step {step}: " + " ".join(f"{n} {x:.4f}" for n, x in zip(LOSS_NAMES, v)))
                state = {"model": model.state_dict(), "optimizer": opt.opt.state_dict(), "step": step, "best": best}
                if v[0] < best:
                    best = v[0]; state["best"] = best
                    torch.save(state, ckpt_dir / "best.pth.tar")
                    print(f"  new best val loss {best:.4f}")
                if step % tc["save_step"] == 0:
                    torch.save(state, ckpt_dir / f"{step}.pth.tar")
                plot_losses(log_dir, res_dir, title)
            if step >= tc["total_step"]:
                break
    torch.save({"model": model.state_dict(), "optimizer": opt.opt.state_dict(), "step": step, "best": best},
               ckpt_dir / "last.pth.tar")
    plot_losses(log_dir, res_dir, title)
    print("done. best validation loss:", best)
