"""FastSpeech 2 (Ren et al., 2021) -- compact re-implementation that follows the architecture and
hyper-parameters of the reference repo ming024/FastSpeech2:
  * Encoder / decoder: stacks of FFT blocks (multi-head self-attention + 2-layer 1-D conv FFN)
  * Variance adaptor: duration, pitch and energy predictors (2x Conv1D+LayerNorm+ReLU+Dropout),
    pitch/energy quantised into 256 linear bins and embedded, length regulator
  * Mel linear projection + 5-layer convolutional PostNet
  * Loss: L1(mel) + L1(postnet mel) + MSE(log duration) + MSE(pitch) + MSE(energy)
Pitch and energy are predicted/used at phoneme level (as in the reference config).
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .utils import read_json, rel


def get_mask_from_lengths(lengths, max_len=None):
    """True = padding."""
    max_len = int(lengths.max()) if max_len is None else max_len
    ids = torch.arange(max_len, device=lengths.device).unsqueeze(0)
    return ids >= lengths.unsqueeze(1)


def sinusoid_table(n_pos, d):
    pos = torch.arange(n_pos).unsqueeze(1).float()
    i = torch.arange(d).unsqueeze(0).float()
    angle = pos / torch.pow(10000, 2 * (i // 2) / d)
    t = torch.zeros(n_pos, d)
    t[:, 0::2] = torch.sin(angle[:, 0::2])
    t[:, 1::2] = torch.cos(angle[:, 1::2])
    return t


class FFTBlock(nn.Module):
    def __init__(self, d, heads, d_inner, ks, drop):
        super().__init__()
        self.attn = nn.MultiheadAttention(d, heads, dropout=drop, batch_first=True)
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.c1 = nn.Conv1d(d, d_inner, ks[0], padding=(ks[0] - 1) // 2)
        self.c2 = nn.Conv1d(d_inner, d, ks[1], padding=(ks[1] - 1) // 2)
        self.drop = nn.Dropout(drop)

    def forward(self, x, pad):
        a, _ = self.attn(x, x, x, key_padding_mask=pad, need_weights=False)
        x = self.ln1(x + self.drop(a)).masked_fill(pad.unsqueeze(-1), 0.0)
        y = self.c2(F.relu(self.c1(x.transpose(1, 2)))).transpose(1, 2)
        return self.ln2(x + self.drop(y)).masked_fill(pad.unsqueeze(-1), 0.0)


class VariancePredictor(nn.Module):
    def __init__(self, d, f, ks, drop):
        super().__init__()
        self.c1 = nn.Conv1d(d, f, ks, padding=(ks - 1) // 2)
        self.c2 = nn.Conv1d(f, f, ks, padding=(ks - 1) // 2)
        self.l1, self.l2 = nn.LayerNorm(f), nn.LayerNorm(f)
        self.drop, self.out = nn.Dropout(drop), nn.Linear(f, 1)

    def forward(self, x, mask):
        h = self.drop(self.l1(F.relu(self.c1(x.transpose(1, 2))).transpose(1, 2)))
        h = self.drop(self.l2(F.relu(self.c2(h.transpose(1, 2))).transpose(1, 2)))
        return self.out(h).squeeze(-1).masked_fill(mask, 0.0)


def length_regulate(x, dur):
    outs = [torch.repeat_interleave(x[b], dur[b].clamp(min=0), dim=0) for b in range(x.size(0))]
    lens = torch.tensor([o.size(0) for o in outs], device=x.device)
    return nn.utils.rnn.pad_sequence(outs, batch_first=True), lens


class PostNet(nn.Module):
    def __init__(self, n_mels=80, emb=512, ks=5, n=5):
        super().__init__()
        chans = [n_mels] + [emb] * (n - 1) + [n_mels]
        self.convs = nn.ModuleList(
            nn.Sequential(nn.Conv1d(chans[i], chans[i + 1], ks, padding=(ks - 1) // 2), nn.BatchNorm1d(chans[i + 1]))
            for i in range(n))

    def forward(self, x):
        x = x.transpose(1, 2)
        for i, c in enumerate(self.convs):
            x = c(x)
            if i < len(self.convs) - 1:
                x = torch.tanh(x)
            x = F.dropout(x, 0.5, self.training)
        return x.transpose(1, 2)


class FastSpeech2(nn.Module):
    def __init__(self, n_symbols, n_speakers, m, stats, n_mels=80, max_seq_len=3000):
        super().__init__()
        h = m["hidden"]
        self.src_emb = nn.Embedding(n_symbols + 1, h, padding_idx=0)  # id 0 = padding
        self.register_buffer("pos", sinusoid_table(max_seq_len + 1, h), persistent=False)
        mk = lambda L: nn.ModuleList(FFTBlock(h, m["heads"], m["ffn_filter"], m["ffn_kernel"], m["dropout"]) for _ in range(L))
        self.enc, self.dec = mk(m["enc_layers"]), mk(m["dec_layers"])
        vp = lambda: VariancePredictor(h, m["vp_filter"], m["vp_kernel"], m["vp_dropout"])
        self.dp, self.pp, self.ep = vp(), vp(), vp()
        nb = m["n_bins"]
        (pmin, pmax), (emin, emax) = stats["pitch"][:2], stats["energy"][:2]
        self.register_buffer("pitch_bins", torch.linspace(pmin, pmax, nb - 1))
        self.register_buffer("energy_bins", torch.linspace(emin, emax, nb - 1))
        self.pitch_emb, self.energy_emb = nn.Embedding(nb, h), nn.Embedding(nb, h)
        self.spk_emb = nn.Embedding(n_speakers, h) if n_speakers > 1 else None
        self.mel_linear = nn.Linear(h, n_mels)
        self.postnet = PostNet(n_mels)

    def forward(self, speakers, texts, src_lens, mel_lens=None, pitches=None, energies=None,
                durations=None, d_control=1.0, p_control=1.0, e_control=1.0):
        src_mask = get_mask_from_lengths(src_lens, texts.size(1))
        x = self.src_emb(texts) + self.pos[: texts.size(1)]
        for l in self.enc:
            x = l(x, src_mask)
        if self.spk_emb is not None:
            x = x + self.spk_emb(speakers).unsqueeze(1)

        # ---- variance adaptor (phoneme level)
        log_d = self.dp(x, src_mask)
        p_pred = self.pp(x, src_mask)
        p_in = pitches if pitches is not None else p_pred * p_control
        x = x + self.pitch_emb(torch.bucketize(p_in, self.pitch_bins))
        e_pred = self.ep(x, src_mask)
        e_in = energies if energies is not None else e_pred * e_control
        x = x + self.energy_emb(torch.bucketize(e_in, self.energy_bins))

        if durations is not None:
            d = durations
        else:
            d = torch.clamp(torch.round((torch.exp(log_d) - 1) * d_control), min=0).long().masked_fill(src_mask, 0)
            if int(d.sum()) == 0:
                d = (~src_mask).long()
        x, mel_len = length_regulate(x, d)
        mel_mask = get_mask_from_lengths(mel_lens if mel_lens is not None else mel_len, x.size(1))

        # ---- decoder
        x = x + self.pos[: x.size(1)]
        for l in self.dec:
            x = l(x, mel_mask)
        mel = self.mel_linear(x)
        post = mel + self.postnet(mel)
        mel, post = mel.masked_fill(mel_mask.unsqueeze(-1), 0.0), post.masked_fill(mel_mask.unsqueeze(-1), 0.0)
        return dict(mel=mel, post=post, p_pred=p_pred, e_pred=e_pred, log_d=log_d, d=d,
                    src_mask=src_mask, mel_mask=mel_mask, mel_lens=mel_len)


def fs2_loss(o, mels, pitches, energies, durations):
    keep_mel, keep_src = ~o["mel_mask"].unsqueeze(-1), ~o["src_mask"]
    mels = mels[:, : o["mel"].size(1)]
    l_mel = F.l1_loss(o["mel"].masked_select(keep_mel), mels.masked_select(keep_mel))
    l_post = F.l1_loss(o["post"].masked_select(keep_mel), mels.masked_select(keep_mel))
    l_p = F.mse_loss(o["p_pred"].masked_select(keep_src), pitches.masked_select(keep_src))
    l_e = F.mse_loss(o["e_pred"].masked_select(keep_src), energies.masked_select(keep_src))
    l_d = F.mse_loss(o["log_d"].masked_select(keep_src), torch.log(durations.float() + 1).masked_select(keep_src))
    total = l_mel + l_post + l_p + l_e + l_d
    return torch.stack([total, l_mel, l_post, l_p, l_e, l_d])


LOSS_NAMES = ["total", "mel", "postnet", "pitch", "energy", "duration"]


def build_model(cfg):
    pp = rel(cfg, cfg["path"]["preprocessed_path"])
    symbols, speakers, stats = read_json(pp / "symbols.json"), read_json(pp / "speakers.json"), read_json(pp / "stats.json")
    return FastSpeech2(len(symbols), len(speakers), cfg["model"], stats, cfg["mel"]["n_mel_channels"])
