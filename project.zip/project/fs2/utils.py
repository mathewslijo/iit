"""Small helpers shared by both language pipelines."""
import json
from pathlib import Path

import yaml


def load_config(path):
    path = Path(path).resolve()
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cfg["_root"] = str(path.parent)  # every relative path in the config is relative to the config file
    return cfg


def rel(cfg, p):
    p = Path(p)
    return p if p.is_absolute() else (Path(cfg["_root"]) / p).resolve()


def read_json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def write_json(obj, p):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
