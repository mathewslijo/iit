"""Text front-ends.

English : normalisation (numbers, times, dates) -> g2p_en -> ARPAbet phones (stress digits removed,
          to match the MFA `english_us_arpa` phone set).
Telugu  : normalisation (numbers, times, ordinals) -> Unicode code-point "graphemes" as tokens
          (the same grapheme units are used as the MFA pronunciation dictionary at training time).
Punctuation that marks a pause (, . ; : ! ?) becomes the silence token `sp`.
"""
import re
import unicodedata

PAUSE_CHARS = ",.;:!?"
MONTHS = "January|February|March|April|May|June|July|August|September|October|November|December"


def _words(n, **kw):
    from num2words import num2words
    return num2words(n, **kw).replace("-", " ").replace(",", "")


# ----------------------------------------------------------------------------- English
def english_normalize(text, for_training=False):
    t = unicodedata.normalize("NFKC", text).replace("’", "'").strip()
    t = re.sub(r"^\(?[A-Za-z]\)\s+", "", t)          # drop list labels such as "a) "
    t = re.sub(r"\[[^\]]*\]|<[^>]*>", " ", t)        # drop annotation tags like [noise]

    def _time(m):
        h, mi, ap = int(m.group(1)), int(m.group(2)), m.group(3)
        s = _words(h)
        if mi == 0:
            s += "" if ap else " o'clock"
        else:
            s += (" oh " if mi < 10 else " ") + _words(mi)
        if ap:
            s += " ay em" if ap.lower().startswith("a") else " pee em"
        return s

    t = re.sub(r"\b(\d{1,2}):(\d{2})\s*([AaPp]\.?[Mm]\.?)?", _time, t)

    def _date(m):
        return f"{_words(int(m.group(1)), to='ordinal')} {m.group(2)} {_words(int(m.group(3)), to='year')}"

    t = re.sub(rf"\b(\d{{1,2}})\s+({MONTHS})\s+(\d{{4}})\b", _date, t)
    t = re.sub(r"\b(1[1-9]\d\d|20\d\d)\b", lambda m: _words(int(m.group(1)), to="year"), t)
    t = re.sub(r"\d+", lambda m: _words(int(m.group(0))), t)
    t = re.sub(r"(?<![A-Za-z])AM(?![A-Za-z])", "ay em", t)
    t = re.sub(r"(?<![A-Za-z])PM(?![A-Za-z])", "pee em", t)
    keep = "a-zA-Z' " if for_training else f"a-zA-Z'{re.escape(PAUSE_CHARS)} "
    t = re.sub(f"[^{keep}]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t.lower() if for_training else t


_g2p = None


def english_to_phones(text):
    global _g2p
    if _g2p is None:
        from g2p_en import G2p
        _g2p = G2p()
    out = []
    for tok in _g2p(english_normalize(text)):
        if tok == " ":
            continue
        if tok in PAUSE_CHARS:
            tok = "sp"
        else:
            tok = re.sub(r"\d", "", tok).upper()
            if not tok.isalpha():
                continue
        if tok == "sp" and out and out[-1] == "sp":
            continue
        out.append(tok)
    return out


# ----------------------------------------------------------------------------- Telugu
_TE_DIGITS = "సున్న ఒకటి రెండు మూడు నాలుగు ఐదు ఆరు ఏడు ఎనిమిది తొమ్మిది".split()
_TE_NUM_DIGITS = str.maketrans("౦౧౨౩౪౫౬౭౮౯", "0123456789")


def telugu_number(n):
    try:
        return _words(n, lang="te")
    except Exception:  # num2words has no Telugu on this install -> digit-by-digit fallback
        return " ".join(_TE_DIGITS[int(c)] for c in str(n))


def telugu_normalize(text, for_training=False):
    t = unicodedata.normalize("NFC", text).translate(_TE_NUM_DIGITS)
    t = t.replace("\u200c", "").replace("\u200d", "")
    t = re.sub(r"^\(?[A-Za-z]\)\s+", "", t)
    t = re.sub(r"\b(\d{1,2}):(\d{2})\b",
               lambda m: telugu_number(int(m.group(1))) + (" " + telugu_number(int(m.group(2))) if int(m.group(2)) else ""), t)
    t = re.sub(r"(\d+)\s*వ\b", lambda m: telugu_number(int(m.group(1))) + "వ", t)
    t = re.sub(r"\d+", lambda m: telugu_number(int(m.group(0))), t)
    keep = r"\u0C00-\u0C7F " if for_training else rf"\u0C00-\u0C7F{re.escape(PAUSE_CHARS)} "
    t = re.sub(f"[^{keep}]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def telugu_to_phones(text):
    out = []
    for ch in telugu_normalize(text):
        if ch == " ":
            continue
        tok = "sp" if ch in PAUSE_CHARS else ch
        if tok == "sp" and out and out[-1] == "sp":
            continue
        out.append(tok)
    return out
