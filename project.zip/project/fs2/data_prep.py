"""Stage 1 of preprocessing: select ~5 h train / ~1 h validation audio from a Hugging Face dataset,
resample to 22.05 kHz mono, and write a corpus (`speaker/utt.wav` + `speaker/utt.lab`) for the aligner.

Subsampling strategy (identical for both languages, see README / report):
  1. keep utterances with a non-empty cleaned transcript and min_dur <= duration <= max_dur seconds;
  2. shuffle with a fixed seed;
  3. fill the TRAIN set from the front of the shuffled list until `train_hours` is reached;
  4. fill the VALIDATION set from the remainder until `val_hours` is reached, skipping any utterance whose
     transcript also occurs in TRAIN  ->  train/val are disjoint by utterance AND by transcript text.
If the dataset is smaller than train+val hours, the 5:1 ratio is kept on what is available.
"""
import io
import random
from collections import defaultdict
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf
from scipy.io import wavfile

from .utils import rel, write_json


def _src(a):
    return io.BytesIO(a["bytes"]) if a.get("bytes") else a["path"]


def _load_hf(dcfg):
    from datasets import Audio, concatenate_datasets, load_dataset
    ds = load_dataset(dcfg["hf_id"], dcfg.get("hf_config"))
    ds = concatenate_datasets(list(ds.values()))  # some corpora ship a single "test" split (Svarah)
    acol = dcfg.get("audio_column") or next(k for k, v in ds.features.items() if isinstance(v, Audio))
    return ds.cast_column(acol, Audio(decode=False)), acol


def _speaker(row, cols):
    for c in cols:
        if c in row and row[c] not in (None, ""):
            return "".join(ch if ch.isalnum() else "_" for ch in str(row[c]))
    return "spk0"


def prepare(cfg, clean_text):
    d, sr = cfg["dataset"], cfg["audio"]["sampling_rate"]
    out = rel(cfg, cfg["path"]["raw_path"])
    ds, acol = _load_hf(d)
    tcol = d.get("text_column", "text")

    # pass 1: cheap scan (duration from the file header only)
    cand = []
    for i in range(len(ds)):
        row = ds[i]
        text = clean_text(row[tcol] or "")
        if len(text) < 3:
            continue
        try:
            dur = sf.info(_src(row[acol])).duration
        except Exception:
            continue
        if d["min_dur"] <= dur <= d["max_dur"]:
            cand.append((i, dur, text, _speaker(row, d["speaker_columns"])))
    random.Random(d["seed"]).shuffle(cand)

    total_h = sum(c[1] for c in cand) / 3600
    tr_t, va_t = d["train_hours"], d["val_hours"]
    if total_h < tr_t + va_t:
        tr_t, va_t = total_h * tr_t / (tr_t + va_t), total_h * va_t / (tr_t + va_t)
    train, val, used, tsec, vsec, train_texts = [], [], set(), 0.0, 0.0, set()
    for k, c in enumerate(cand):
        if tsec < tr_t * 3600:
            train.append(c); used.add(k); tsec += c[1]; train_texts.add(c[2])
        else:
            break
    for k, c in enumerate(cand):
        if k in used or c[2] in train_texts:
            continue
        if vsec >= va_t * 3600:
            break
        val.append(c); vsec += c[1]

    # pass 2: write audio + transcripts
    manifest = []
    for split, items in (("train", train), ("val", val)):
        for i, dur, text, spk in items:
            uid = f"{spk}_{i:06d}"
            wav, _ = librosa.load(_src(ds[i][acol]), sr=sr, mono=True)
            wav = wav / max(np.abs(wav).max(), 1e-6) * 0.95
            sd = out / spk
            sd.mkdir(parents=True, exist_ok=True)
            wavfile.write(sd / f"{uid}.wav", sr, (wav * 32767).astype(np.int16))
            (sd / f"{uid}.lab").write_text(text, encoding="utf-8")
            manifest.append(dict(id=uid, speaker=spk, split=split, duration=round(dur, 3), text=text))
    pp = rel(cfg, cfg["path"]["preprocessed_path"])
    pp.mkdir(parents=True, exist_ok=True)
    write_json(manifest, pp / "split_manifest.json")
    stats = defaultdict(float)
    spk_sets = defaultdict(set)
    for m in manifest:
        stats[m["split"] + "_hours"] += m["duration"] / 3600
        stats[m["split"] + "_utts"] += 1
        spk_sets[m["split"]].add(m["speaker"])
    summary = dict(dataset=d["hf_id"], eligible_hours=round(total_h, 2), seed=d["seed"],
                   **{k: round(v, 3) for k, v in stats.items()},
                   train_speakers=len(spk_sets["train"]), val_speakers=len(spk_sets["val"]),
                   utterance_overlap=0, transcript_overlap=len(set(m["text"] for m in manifest if m["split"] == "train")
                                                                & set(m["text"] for m in manifest if m["split"] == "val")))
    write_json(summary, pp / "dataset_summary.json")
    print(summary)
