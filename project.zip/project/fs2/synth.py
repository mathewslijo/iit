"""Inference: text -> phones -> mel -> HiFi-GAN waveform, plus variance-adaptor plots/values."""
import csv
from pathlib import Path

import numpy as np
import torch
from scipy.io import wavfile

from .hifigan import load_vocoder
from .model import build_model
from .utils import load_config, read_json, rel

TELUGU_FONTS = ["Noto Sans Telugu", "Lohit Telugu", "Gautami", "Nirmala UI", "Pothana2000", "Vani", "Akshar Unicode"]


def _setup_font(lang):
    import matplotlib.font_manager as fm
    import matplotlib.pyplot as plt
    if lang != "telugu":
        return
    have = {f.name for f in fm.fontManager.ttflist}
    for f in TELUGU_FONTS:
        if f in have:
            plt.rcParams["font.family"] = [f, "DejaVu Sans"]; return
    print("WARNING: no Telugu font found; install `fonts-noto` / Lohit Telugu so phone labels render in the plots.")


def plot_variance(phones, d, pitch_hz, energy, name, out_root, sr, hop):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    out_root = Path(out_root)
    sec = d * hop / sr
    edges = np.concatenate([[0], np.cumsum(sec)])
    mid = (edges[:-1] + edges[1:]) / 2
    n = len(phones)
    w = max(8, 0.32 * n)

    fig, ax = plt.subplots(figsize=(w, 3.8))                                 # --- duration
    ax.bar(range(n), sec * 1000, color="tab:blue")
    ax.set_xticks(range(n)); ax.set_xticklabels(phones, rotation=90, fontsize=8)
    ax.set_ylabel("predicted duration (ms)"); ax.set_title(f"{name}: predicted phoneme duration "
                                                           f"(total {edges[-1]:.2f} s, {int(d.sum())} frames)")
    ax.grid(axis="y", alpha=.3); fig.tight_layout(); fig.savefig(out_root / "duration" / f"{name}_duration.png", dpi=150); plt.close(fig)

    for key, vals, ylab, col in (("pitch", pitch_hz, "predicted F0 (Hz)", "tab:red"),
                                 ("energy", energy, "predicted energy (STFT L2 norm)", "tab:green")):
        fig, ax = plt.subplots(figsize=(w, 3.8))                              # --- pitch / energy over time
        ax.step(edges, np.append(vals, vals[-1]), where="post", color=col, lw=1.8)
        for e in edges:
            ax.axvline(e, color="gray", lw=.4, alpha=.5)
        top = ax.get_ylim()[1]
        for m_, p_ in zip(mid, phones):
            ax.text(m_, top, p_, ha="center", va="bottom", fontsize=7, rotation=90)
        ax.set_xlabel("time (s)"); ax.set_ylabel(ylab); ax.set_xlim(0, edges[-1])
        ax.set_title(f"{name}: predicted {key} per phoneme (aligned to predicted durations)", pad=28)
        fig.tight_layout(); fig.savefig(out_root / key / f"{name}_{key}.png", dpi=150); plt.close(fig)


def run(cfg_path, ckpt, sentences, to_phones, speaker=None, device=None, d_control=1.0, p_control=1.0, e_control=1.0):
    cfg = load_config(cfg_path)
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    pp = rel(cfg, cfg["path"]["preprocessed_path"])
    symbols, speakers, stats = read_json(pp / "symbols.json"), read_json(pp / "speakers.json"), read_json(pp / "stats.json")
    s2i = {s: i + 1 for i, s in enumerate(symbols)}
    spk = speaker if speaker in speakers else next(iter(speakers))
    model = build_model(cfg).to(dev)
    model.load_state_dict(torch.load(ckpt, map_location=dev)["model"]); model.eval()
    voc = load_vocoder(rel(cfg, cfg["vocoder"]["hifigan_ckpt"]), dev)
    sr, hop = cfg["audio"]["sampling_rate"], cfg["stft"]["hop_length"]
    res = rel(cfg, cfg["path"]["results_path"])
    wav_dir, var_dir = res / "test_generated_audios", res / "variance_adaptor_plots"
    for p in (wav_dir, var_dir / "duration", var_dir / "pitch", var_dir / "energy", var_dir / "values"):
        p.mkdir(parents=True, exist_ok=True)
    _setup_font(cfg["language"])
    p_mean, p_std = stats["pitch"][2:]
    e_mean, e_std = stats["energy"][2:]

    for name, text in sentences.items():
        phones = to_phones(text)
        unk = [p for p in phones if p not in s2i]
        if unk:
            print(f"[{name}] WARNING: symbols not seen in training were dropped: {sorted(set(unk))}")
        phones = [p for p in phones if p in s2i]
        ids = torch.tensor([[s2i[p] for p in phones]], device=dev)
        with torch.no_grad():
            o = model(torch.tensor([speakers[spk]], device=dev), ids, torch.tensor([ids.size(1)], device=dev),
                      d_control=d_control, p_control=p_control, e_control=e_control)
            wav = voc(o["post"].transpose(1, 2))[0, 0].cpu().numpy()
        wavfile.write(wav_dir / f"{name}.wav", sr, (wav * 32768.0).clip(-32768, 32767).astype("int16"))
        d = o["d"][0].cpu().numpy()
        p_hz = np.clip(o["p_pred"][0].cpu().numpy() * p_std + p_mean, 0, None)
        en = np.clip(o["e_pred"][0].cpu().numpy() * e_std + e_mean, 0, None)
        plot_variance(phones, d, p_hz, en, name, var_dir, sr, hop)
        with open(var_dir / "values" / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["idx", "phone", "duration_frames", "duration_ms", "f0_hz", "energy"])
            for i, (ph, dd, pp_, ee) in enumerate(zip(phones, d, p_hz, en)):
                w.writerow([i, ph, int(dd), round(dd * hop / sr * 1000, 1), round(float(pp_), 1), round(float(ee), 3)])
        print(f"[{name}] {len(phones)} phones -> {len(wav) / sr:.2f}s audio (speaker: {spk})")
