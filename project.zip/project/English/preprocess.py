"""English preprocessing (Svarah).   python preprocess.py --stage {prepare,align,features,all}

  prepare  : select ~5 h train / ~1 h val, resample to 22.05 kHz, write corpus + .lab (see fs2/data_prep.py)
  align    : Montreal Forced Aligner with the pretrained `english_us_arpa` acoustic model + dictionary
  features : durations, mel, phoneme-level pitch (WORLD) and energy -> preprocessed_data/
"""
import argparse
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fs2 import data_prep, features
from fs2.text import english_normalize
from fs2.utils import load_config, rel


def align(cfg, jobs):
    raw, tg = rel(cfg, cfg["path"]["raw_path"]), rel(cfg, cfg["path"]["textgrid_path"])
    for kind in ("acoustic", "dictionary"):
        subprocess.run(["mfa", "model", "download", kind, "english_us_arpa"], check=True)
    subprocess.run(["mfa", "align", str(raw), "english_us_arpa", "english_us_arpa", str(tg),
                    "--clean", "--overwrite", "-j", str(jobs)], check=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(Path(__file__).with_name("config.yaml")))
    ap.add_argument("--stage", default="all", choices=["prepare", "align", "features", "all"])
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    cfg = load_config(a.config)
    if a.stage in ("prepare", "all"):
        data_prep.prepare(cfg, lambda t: english_normalize(t, for_training=True))
    if a.stage in ("align", "all"):
        align(cfg, a.jobs)
    if a.stage in ("features", "all"):   # strip ARPAbet stress digits so training/inference phone sets match
        features.run(cfg, fix_phone=lambda p: re.sub(r"\d", "", p).upper())
