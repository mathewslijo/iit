"""python train.py [--resume checkpoints/XXXX.pth.tar] [--plot-only]"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fs2 import trainer

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(Path(__file__).with_name("config.yaml")))
    ap.add_argument("--resume", default=None)
    ap.add_argument("--plot-only", action="store_true", help="only re-draw the loss plots from logs/")
    a = ap.parse_args()
    trainer.run(a.config, a.resume, a.plot_only)
