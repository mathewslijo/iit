"""python inference.py --ckpt checkpoints/best.pth.tar [--speaker NAME]
Synthesises the five English test sentences and writes audio + duration/pitch/energy plots to ../Results/English."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fs2 import synth
from fs2.text import english_to_phones

# Test sentences exactly as given in the assignment (the "a)"/"b)" labels are the IDs E2a / E2b).
TEST_SENTENCES = {
    "E1": "The antidisestablishmentarianism movement gained considerable momentum during the parliamentary proceedings.",
    "E2a": "The orchestra's conduct during the ceremony was praised by the audience.",
    "E2b": "The researchers will conduct an experiment to evaluate the proposed method.",
    "E3": "The rhyth m of the orchestra changed unexpectedly.",
    "E4": "The meeting will start at 10:45 AM on 12 November 2026, so andaroo should arrive on time.",
}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(Path(__file__).with_name("config.yaml")))
    ap.add_argument("--ckpt", default=str(Path(__file__).parent / "checkpoints" / "best.pth.tar"))
    ap.add_argument("--speaker", default=None, help="speaker id from preprocessed_data/speakers.json (same for all sentences)")
    ap.add_argument("--device", default=None)
    ap.add_argument("--d_control", type=float, default=1.0)
    ap.add_argument("--p_control", type=float, default=1.0)
    ap.add_argument("--e_control", type=float, default=1.0)
    a = ap.parse_args()
    synth.run(a.config, a.ckpt, TEST_SENTENCES, english_to_phones, a.speaker, a.device, a.d_control, a.p_control, a.e_control)
