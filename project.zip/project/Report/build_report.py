"""Builds Technical_Report.pdf from the repo contents (configs, logs, results, observations.yaml).
Run from anywhere:  python Report/build_report.py        (re-run after training/inference/observations)"""
import csv
import json
import sys
from pathlib import Path

import yaml
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, Preformatted

ROOT = Path(__file__).resolve().parents[1]
OBS = yaml.safe_load(open(Path(__file__).with_name("observations.yaml"), encoding="utf-8"))
ss = getSampleStyleSheet()
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=9.5, leading=13)
H1, H2 = ss["Heading1"], ss["Heading2"]
SM = ParagraphStyle("SM", parent=B, fontSize=8, leading=10)
CODE = ParagraphStyle("C", fontName="Courier", fontSize=7.5, leading=9.5, backColor=colors.whitesmoke)
LANGS = {"English": ["E1", "E2a", "E2b", "E3", "E4"], "Telugu": ["T1", "T2a", "T2b", "T3", "T4"]}


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def P(t, st=B):
    return Paragraph(t, st)


def obs(v):
    v = "TODO" if v is None else str(v).strip()
    if v.upper().startswith("TODO"):
        return P('<font color="red">[TO COMPLETE AFTER TRAINING - see Report/observations.yaml]</font>')
    return P(esc(v))


def table(rows, widths=None, head=True):
    t = Table([[P(esc(c), SM) if not isinstance(c, Paragraph) else c for c in r] for r in rows], colWidths=widths, repeatRows=1 if head else 0)
    st = [("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if head:
        st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dde6f3")))
    t.setStyle(TableStyle(st))
    return t


def img(path, width=16.5 * cm):
    from PIL import Image as PI
    if not path.exists():
        return P(f'<font color="red">[missing figure: {esc(path.relative_to(ROOT))}]</font>', SM)
    w, h = PI.open(path).size
    return Image(str(path), width=width, height=width * h / w)


def read_csv(p):
    if not p.exists():
        return None
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def cfg_of(lang):
    return yaml.safe_load(open(ROOT / lang / "config.yaml", encoding="utf-8"))


def loss_stats(lang):
    tr, va = read_csv(ROOT / lang / "logs" / "train_loss.csv"), read_csv(ROOT / lang / "logs" / "val_loss.csv")
    if not tr or not va:
        return None
    best = min(va, key=lambda r: float(r["total"]))
    return [["metric", "value"],
            ["logged train points / val evaluations", f"{len(tr)} / {len(va)}"],
            ["final train total loss (step %s)" % tr[-1]["step"], tr[-1]["total"]],
            ["final val total loss (step %s)" % va[-1]["step"], va[-1]["total"]],
            ["best val total loss (step %s)" % best["step"], best["total"]],
            ["val mel / postnet / pitch / energy / duration at best",
             " / ".join(best[k] for k in ("mel", "postnet", "pitch", "energy", "duration"))]]


story = [P("Implementation of FastSpeech 2-Based Text-to-Speech Synthesis", ss["Title"]),
         P("Technical Report - English (Svarah) and Telugu (IndicTTS Telugu)", ss["Heading3"]), Spacer(1, 8)]

# 1 -------------------------------------------------------------------------------------------
story += [P("1. Implementation approach", H1),
          P("Two independent FastSpeech 2 models (Ren et al., 2021) were trained, one for English and one for Telugu. The architecture, "
            "hyper-parameters, loss, optimiser schedule and feature-extraction recipe follow the reference implementation "
            "(github.com/ming024/FastSpeech2). The code was reorganised into a compact shared package <b>fs2/</b> "
            "(model, data, features, trainer, synthesis) with a thin language-specific layer in <b>English/</b> and <b>Telugu/</b> "
            "(config, preprocessing, text front-end, test sentences)."),
          table([["Component", "Taken from reference", "Notes / modification"],
                 ["Encoder / decoder", "4 / 6 FFT blocks, hidden 256, 2 heads, conv FFN kernels (9,1), filter 1024, dropout 0.2", "re-implemented (fs2/model.py); nn.MultiheadAttention with key-padding masks"],
                 ["Variance adaptor", "duration (log), pitch and energy predictors: 2x Conv1D(k=3,256)+LN+ReLU+Dropout(0.5); 256 linear bins + embeddings; length regulator", "pitch/energy at phoneme level; global z-score normalisation"],
                 ["Mel decoder head", "linear projection + 5-layer conv PostNet", "unchanged"],
                 ["Loss", "L1 mel + L1 post-net mel + MSE log-duration + MSE pitch + MSE energy", "unchanged (all weights 1)"],
                 ["Optimiser", "Adam(0.9,0.98,1e-9), warm-up 4000, step annealing x0.3, grad-clip 1.0", "shorter schedule (60k steps) for the 5 h budget"],
                 ["Aligner", "Montreal Forced Aligner TextGrids", "English: pretrained english_us_arpa. Telugu: acoustic model trained from scratch on the subset"],
                 ["Vocoder", "pretrained universal HiFi-GAN", "same checkpoint for both languages; generator re-implemented in fs2/hifigan.py"],
                 ["English front-end", "g2p_en / ARPAbet", "stress digits removed to match MFA phone set; numbers, times and dates expanded (num2words)"],
                 ["Telugu front-end", "not available in reference", "NEW: Unicode-grapheme tokens, ZWJ/ZWNJ stripping, Telugu numerals->ASCII, Telugu number/time/ordinal expansion, grapheme MFA dictionary"]],
                [3 * cm, 7 * cm, 7 * cm])]

# 2 -------------------------------------------------------------------------------------------
story += [P("2. Datasets, preprocessing and training configuration", H1)]
for lang in LANGS:
    cfg, summ = cfg_of(lang), None
    sp = ROOT / lang / "preprocessed_data" / "dataset_summary.json"
    if sp.exists():
        summ = json.load(open(sp, encoding="utf-8"))
    d, t = cfg["dataset"], cfg["train"]
    story += [P(f"2.{list(LANGS).index(lang) + 1} {lang}", H2),
              P(f"Dataset: <b>{d['hf_id']}</b>. Selection: clips {d['min_dur']}-{d['max_dur']} s with non-empty cleaned transcript, shuffled with seed {d['seed']}; "
                f"first ~{d['train_hours']} h to train, next ~{d['val_hours']} h to validation (transcripts occurring in train are skipped, so "
                "train/validation share neither utterances nor transcripts). Audio resampled to 22.05 kHz mono; 80-bin log-mel (n_fft 1024, hop 256, "
                "fmax 8 kHz); WORLD F0 (DIO+StoneMask, unvoiced frames interpolated) and STFT-L2 frame energy averaged per phoneme; z-score "
                "normalisation with train statistics.")]
    story.append(table([["measured", "value"]] + [[k, v] for k, v in summ.items()]) if summ else
                 P('<font color="red">[dataset_summary.json not found - run preprocess.py and re-build]</font>'))
    story += [Spacer(1, 4),
              table([["training setting", "value"], ["batch size / total steps", f"{t['batch_size']} / {t['total_step']}"],
                     ["warm-up / anneal steps / rate", f"{t['warm_up_step']} / {t['anneal_steps']} / {t['anneal_rate']}"],
                     ["validate / save every", f"{t['val_step']} / {t['save_step']} steps"], ["grad clip, seed", f"{t['grad_clip']}, {t['seed']}"]])]

# 3 -------------------------------------------------------------------------------------------
story += [PageBreak(), P("3. Training and validation loss", H1)]
for lang in LANGS:
    story += [P(lang, H2)]
    ls = loss_stats(lang)
    story.append(table(ls) if ls else P('<font color="red">[logs not found]</font>'))
    story += [img(ROOT / "Results" / lang / "training_loss.png", 15 * cm), img(ROOT / "Results" / lang / "validation_loss.png", 15 * cm),
              obs(OBS.get(f"loss_{lang.lower()}"))]

# 4 -------------------------------------------------------------------------------------------
story += [PageBreak(), P("4. Generated speech - per sentence observations", H1),
          P("Sentence texts are stored verbatim in English/inference.py and Telugu/inference.py (IDs below); audio is in Results/&lt;Lang&gt;/test_generated_audios/.", SM)]
for lang, ids in LANGS.items():
    story.append(P(lang, H2))
    rows = [["ID", "phones", "audio length (s)", "observation (pronunciation / quality)"]]
    for i in ids:
        v = read_csv(ROOT / "Results" / lang / "variance_adaptor_plots" / "values" / f"{i}.csv")
        n = len(v) if v else "-"
        ln = f"{sum(float(r['duration_ms']) for r in v) / 1000:.2f}" if v else "-"
        rows.append([i, n, ln, obs(OBS.get(f"speech_{lang.lower()}", {}).get(i))])
    story.append(table(rows, [1.4 * cm, 1.5 * cm, 2.3 * cm, 12 * cm]))

# 5 -------------------------------------------------------------------------------------------
story += [PageBreak(), P("5. Variance-adaptor analysis (duration, pitch F0, energy)", H1),
          P("Duration bars show predicted frames converted to ms (hop 256 / 22.05 kHz = 11.6 ms). Pitch and energy are the phoneme-level predictions "
            "de-normalised with the training statistics and drawn over the predicted time axis. Numeric values are in "
            "Results/&lt;Lang&gt;/variance_adaptor_plots/values/*.csv.", SM)]
for lang, ids in LANGS.items():
    for i in ids:
        story += [P(f"{lang} - {i}", H2), obs(OBS.get(f"variance_{lang.lower()}", {}).get(i))]
        for k in ("duration", "pitch", "energy"):
            story.append(img(ROOT / "Results" / lang / "variance_adaptor_plots" / k / f"{i}_{k}.png", 15.5 * cm))
        story.append(PageBreak())

# 6 -------------------------------------------------------------------------------------------
story += [P("6. English vs Telugu: comparison, limitations, improvements", H1), obs(OBS.get("comparison")),
          P("Known design-level limitations of this implementation (independent of the trained results):", B),
          P("- Telugu uses grapheme tokens: schwa/vowel-sign interactions, geminates and conjunct pronunciation are learned from data only; no Telugu G2P or lexicon is used.<br/>"
            "- Telugu alignments come from an MFA model trained from scratch on ~6 h, so boundary accuracy (hence the duration targets) is lower than for English, which uses a pretrained aligner.<br/>"
            "- Pauses are modelled only through punctuation -> 'sp'; words are not delimited in the token sequence (as in the reference).<br/>"
            "- English heteronyms (E2a/E2b) depend on g2p_en part-of-speech disambiguation; out-of-vocabulary words (E1, E3, E4 'andaroo') are handled by the neural G2P.<br/>"
            "- The test text for several Telugu sentences contains irregular spacing / ordering of consonants and virama (kept verbatim as required); the model receives these characters as-is.<br/>"
            "- Both languages share one universal HiFi-GAN vocoder that was not fine-tuned.", B)]

# 7 -------------------------------------------------------------------------------------------
story += [PageBreak(), P("7. Reproducibility", H1),
          P("Software: Python 3.10, PyTorch &gt;= 2.1, librosa, pyworld, tgt, datasets, g2p_en, num2words, matplotlib; Montreal Forced Aligner 3.x (conda). "
            "Full list in requirements.txt. Seeds: data split 1234, training 1234. Configuration: English/config.yaml, Telugu/config.yaml.", B),
          Preformatted("""# per language (cd English  |  cd Telugu)
python preprocess.py --stage all      # prepare -> MFA align -> features
python train.py                       # checkpoints/, logs/, Results/<Lang>/*_loss.png
python inference.py --ckpt checkpoints/best.pth.tar
python train.py --plot-only           # redraw loss plots from logs
# report
python Report/build_report.py""", CODE)]

out = Path(__file__).with_name("Technical_Report.pdf")
SimpleDocTemplate(str(out), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=2 * cm, bottomMargin=2 * cm,
                  title="FastSpeech 2 TTS - Technical Report").build(story)
print("wrote", out)
