# FastSpeech 2 TTS -- English (Svarah) and Telugu (IndicTTS Telugu)

Two separate FastSpeech 2 models (Ren et al., 2021, <https://arxiv.org/abs/2006.04558>), one per language,
following the architecture, hyper-parameters and preprocessing recipe of the reference implementation
<https://github.com/ming024/FastSpeech2>.

```
project/
├── fs2/                 shared FastSpeech 2 package (model, data, features, trainer, synthesis, HiFi-GAN, text front-ends)
├── English/             train.py  preprocess.py  inference.py  config.yaml  checkpoints/
├── Telugu/              train.py  preprocess.py  inference.py  config.yaml  checkpoints/
├── Results/{English,Telugu}/  training_loss.png  validation_loss.png  test_generated_audios/  variance_adaptor_plots/{duration,pitch,energy}
├── Report/              Technical_Report.pdf (+ build_report.py, observations.yaml)
├── hifigan/             pretrained vocoder (not committed; see hifigan/README.md)
├── README.md
└── requirements.txt
```
`fs2/` is the only addition to the required layout; it holds the code both languages share so that the
language folders contain only language-specific logic (dataset id, text front-end, aligner set-up, test sentences, config).

## What differs from the reference repo
| Area | Reference (ming024) | This project |
|---|---|---|
| Code | multi-file repo, LJSpeech/AISHELL3/LibriTTS | compact re-implementation of the same model/loss/optimiser schedule in `fs2/` (single package, HF-dataset ingestion, CSV loss logging, plotting) |
| Data | local corpora | Hugging Face datasets, ~5 h train / ~1 h val subsampling with fixed seed and train/val disjointness checks (`fs2/data_prep.py`) |
| English text | MFA + librispeech lexicon, g2p_en | MFA `english_us_arpa` (pretrained), g2p_en at inference, stress digits stripped, number/time/date normalisation |
| **Telugu text** | -- (not supported) | grapheme tokens (Unicode code points); **MFA acoustic model trained from scratch** on the Telugu subset using an auto-generated grapheme dictionary; Telugu number/time/ordinal normalisation (`fs2/text.py`) |
| Speakers | multi-speaker option | Svarah: multi-speaker embedding; IndicTTS Telugu: speaker embedding over its speakers (gender id when no speaker id column) |
| Vocoder | HiFi-GAN | same pretrained universal HiFi-GAN generator (`fs2/hifigan.py`) |
| Extras | -- | duration/pitch/energy plots + CSV values per test sentence, loss plots |

## Setup
```bash
conda create -n fs2 python=3.10 -y && conda activate fs2
pip install -r requirements.txt
python -c "import nltk; [nltk.download(p) for p in ['averaged_perceptron_tagger','averaged_perceptron_tagger_eng','cmudict']]"
conda install -c conda-forge montreal-forced-aligner=3.* -y     # needed only for preprocessing
huggingface-cli login      # Svarah / IndicTTS may require accepting the dataset terms
# put generator_universal.pth.tar in ./hifigan/  (see hifigan/README.md)
sudo apt install fonts-noto-core    # Telugu glyphs in the Telugu plots
```

## Reproduce (run once per language)
```bash
cd English            # or: cd Telugu
python preprocess.py --stage all          # prepare -> MFA align -> features   (stages can be run separately)
python train.py                           # logs/*.csv, checkpoints/*.pth.tar, ../Results/<Lang>/{training,validation}_loss.png
python inference.py --ckpt checkpoints/best.pth.tar     # ../Results/<Lang>/test_generated_audios + variance_adaptor_plots
```
Useful: `python train.py --resume checkpoints/<step>.pth.tar`, `python train.py --plot-only`,
`python inference.py --speaker <id> --d_control 1.0 --p_control 1.0 --e_control 1.0`.
Then build the report: `cd Report && python build_report.py` (after filling `observations.yaml`).

## Data selection (details are written to `preprocessed_data/dataset_summary.json` + `split_manifest.json`)
1. Concatenate all splits of the HF dataset; keep clips 1-15 s with a non-empty cleaned transcript.
2. Shuffle (seed 1234); first ~5 h -> train; subsequent ~1 h -> validation, skipping any clip whose transcript also appears in train
   (so train/val share no utterances and no transcripts; speakers may overlap for multi-speaker Svarah).
3. Resample to 22.05 kHz mono, peak-normalise; mel (80 bins, n_fft 1024, hop 256, fmax 8 kHz); WORLD F0 (DIO+StoneMask, unvoiced frames
   interpolated) and frame-energy (L2 norm of STFT) averaged per phoneme; global z-score normalisation with train statistics; 256 linear bins.

## Checkpoints
`English/checkpoints/best.pth.tar` and `Telugu/checkpoints/best.pth.tar` (tracked with Git LFS, see `.gitattributes`).
If they exceed LFS quota, upload them elsewhere and put the link here: **<ADD LINK>**.

## Notes / limitations
* Validation loss is teacher-forced (ground-truth duration/pitch/energy are fed to the decoder), exactly as in the reference code.
* English test sentence E2 (a/b) tests the heteronym *conduct* (noun vs verb); this relies on g2p_en's POS-based disambiguation.
* Test sentences are stored verbatim in `English/inference.py` and `Telugu/inference.py` (labels "a)", "b)" become the IDs E2a/E2b, T2a/T2b).
