"""Telugu preprocessing (IndicTTS Telugu).   python preprocess.py --stage {prepare,align,features,all}

  prepare  : select ~5 h train / ~1 h val, resample to 22.05 kHz, write corpus + .lab (see fs2/data_prep.py)
  align    : no pretrained Telugu MFA model is assumed -> a grapheme dictionary (word -> Unicode characters) is
             generated from the transcripts and an MFA acoustic model is TRAINED FROM SCRATCH on the corpus
  features : durations, mel, phoneme-level pitch (WORLD) and energy -> preprocessed_data/
"""
import argparse
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fs2 import data_prep, features
from fs2.text import telugu_normalize
from fs2.utils import load_config, rel


def build_grapheme_dict(raw, out):
    words = set()
    for lab in raw.rglob("*.lab"):
        words.update(lab.read_text(encoding="utf-8").split())
    with open(out, "w", encoding="utf-8") as f:
        for w in sorted(words):
            f.write(f"{w}\t{' '.join(w)}\n")          # each Unicode code point is one "phone"
    print(f"grapheme dictionary: {len(words)} words -> {out}")


def align(cfg, jobs):
    raw, tg = rel(cfg, cfg["path"]["raw_path"]), rel(cfg, cfg["path"]["textgrid_path"])
    pp = rel(cfg, cfg["path"]["preprocessed_path"])
    dic = pp / "telugu_graphemes.dict"
    build_grapheme_dict(raw, dic)
    subprocess.run(["mfa", "train", str(raw), str(dic), str(pp / "telugu_mfa_acoustic.zip"),
                    "--output_directory", str(tg), "--clean", "--overwrite", "-j", str(jobs)], check=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(Path(__file__).with_name("config.yaml")))
    ap.add_argument("--stage", default="all", choices=["prepare", "align", "features", "all"])
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    cfg = load_config(a.config)
    if a.stage in ("prepare", "all"):
        data_prep.prepare(cfg, lambda t: telugu_normalize(t, for_training=True))
    if a.stage in ("align", "all"):
        align(cfg, a.jobs)
    if a.stage in ("features", "all"):
        features.run(cfg)
