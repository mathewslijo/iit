"""python inference.py --ckpt checkpoints/best.pth.tar [--speaker NAME]
Synthesises the five Telugu test sentences and writes audio + duration/pitch/energy plots to ../Results/Telugu.
Plot labels need a Telugu font (e.g. `sudo apt install fonts-noto-core` -> "Noto Sans Telugu")."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fs2 import synth
from fs2.text import telugu_to_phones

# Test sentences exactly as given in the assignment PDF (the "a)"/"b)" labels are the IDs T2a / T2b).
TEST_SENTENCES = {
    "T1": "న్యూ రోఫార్మ కోలాజికల్ పరిశోధనలోనూతన ఔషధాల ప్రభావాన్ని విశ్లషే ించారు.",
    "T2a": "తాడుపై అతని పట్టుచాలా బలంగా ఉంది.",
    "T2b": "ఆమె పట్టుచీరను ధరించి వేడుకకు వచ్చ ింది.",
    "T3": "పులి అడ విలో నిశ్శబ్ంద గా నడిచింది.",
    "T4": "ఈ సమావేశం 2026 నవంబర్ 12వ తేదీ ఉదయం 10:45 గంటలకు ప్రారంభమవుతుంది, సమయానికి సిద్ంధ గా ఉంచండి.",
}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(Path(__file__).with_name("config.yaml")))
    ap.add_argument("--ckpt", default=str(Path(__file__).parent / "checkpoints" / "best.pth.tar"))
    ap.add_argument("--speaker", default=None, help="speaker id from preprocessed_data/speakers.json (e.g. female/male)")
    ap.add_argument("--device", default=None)
    ap.add_argument("--d_control", type=float, default=1.0)
    ap.add_argument("--p_control", type=float, default=1.0)
    ap.add_argument("--e_control", type=float, default=1.0)
    a = ap.parse_args()
    synth.run(a.config, a.ckpt, TEST_SENTENCES, telugu_to_phones, a.speaker, a.device, a.d_control, a.p_control, a.e_control)
